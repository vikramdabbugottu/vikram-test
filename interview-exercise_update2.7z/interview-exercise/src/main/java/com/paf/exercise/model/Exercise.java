package com.paf.exercise.model;

import javax.persistence.Entity;

@Entity
public class Exercise {
	
	public int tournament_id;
	public int reward_amount;
	public int player_id;
	public String player_name;
	
	public int getTournament_id() {
		return tournament_id;
	}
	public void setTournament_id(int tournament_id) {
		this.tournament_id = tournament_id;
	}
	public int getReward_amount() {
		return reward_amount;
	}
	public void setReward_amount(int reward_amount) {
		this.reward_amount = reward_amount;
	}
	public int getPlayer_id() {
		return player_id;
	}
	public void setPlayer_id(int player_id) {
		this.player_id = player_id;
	}
	public String getPlayer_name() {
		return player_name;
	}
	public void setPlayer_name(String player_name) {
		this.player_name = player_name;
	}
	

}
