CREATE TABLE exercise(
  id INT PRIMARY KEY,
  tournament_id INT,
  reward_amount INT,
  player_id INT,
  player_name VARCHAR
);