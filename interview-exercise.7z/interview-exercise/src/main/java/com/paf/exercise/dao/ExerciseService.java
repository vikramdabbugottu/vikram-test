package com.paf.exercise.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.paf.exercise.model.Exercise;

@Service
public class ExerciseService 
{
	
	private Exercise exercise;
	
	@Autowired
	public JdbcTemplate jdbcTemplate;
	
	List<Exercise> list = new ArrayList<>();
	
	//get tournment with null id
	

	
	//if option is get tournment
	
	public void getTournment(Integer tournament_id)
	{
		
		Exercise e = jdbcTemplate.queryForObject("select * from exercise where tournament_id=" + tournament_id,
				new ExerciseMapper());
		list.add(e);
	}
	
	//option is add tournment
	
	public void addTournment(Integer reward_amount)
	{
		Random random = new Random();
		int id = random.nextInt();
		int tournamentId = random.nextInt();
		jdbcTemplate.execute("insert into exercise(id, tournament_id, reward_amount) " +
				"values(" + id + ", " + tournamentId + ", " + reward_amount + ")");
	}
	
	//option is update tournment
	
	public void updateTournment(Integer reward_amount, Integer tournament_id )
	{
		jdbcTemplate.execute("update exercise set reward_amount=" + reward_amount +
				" where tournament_id=" + tournament_id);
	}
	
	//option is remove tournment
	
	public void removeTournment(int tournament_id)
	{
		jdbcTemplate.execute("delete from exercise where tournament_id=" + tournament_id);
	}
	
	//option is add player into tournment
	
	public void addPlayer(int tournament_id, String player_name)
	{
		Random random = new Random();
		int id = random.nextInt();
		int playerId = random.nextInt();
		jdbcTemplate.execute("insert into exercise(id, tournament_id, player_id, player_name) " +
				"values(" + id + ", " + tournament_id + ", " + playerId + ", '" + player_name + "')");
	}
	
	//option is remove player into tournment
	
	public void removePlayer(int tournament_id, int player_id)
	{
		jdbcTemplate.execute("delete from exercise where tournament_id=" + tournament_id
				+ " and player_id=" + player_id);
	}
	
	//option is get all players in the tournment
	
	public void getallPlayers(int tournament_id)
	{
		list = jdbcTemplate.query("select * from exercise where tournament_id=" + tournament_id +
				" and player_id is not null", new RowMapper<Exercise>() {
			@Override
			public Exercise mapRow(ResultSet resultSet, int i) throws SQLException {
				Exercise e = new Exercise();
				e.tournament_id = resultSet.getInt("tournament_id");
				e.player_id = resultSet.getInt("player_id");
				e.player_name = resultSet.getString("player_name");
				return e;
			}
		});
		
	}
		
	
}
