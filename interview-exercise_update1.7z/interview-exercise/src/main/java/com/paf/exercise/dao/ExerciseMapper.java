package com.paf.exercise.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.paf.exercise.model.Exercise;

public class ExerciseMapper implements RowMapper<Exercise>
{

	@Override
	public Exercise mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		Exercise e = new Exercise();
		e.tournament_id = resultSet.getInt("tournament_id");
		e.reward_amount = resultSet.getInt("reward_amount");
		e.player_id = resultSet.getInt("player_id");
		e.player_name = resultSet.getString("player_name");
		return e;
	}
	

}
