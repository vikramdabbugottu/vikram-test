package com.paf.exercise.exercise;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.paf.exercise.dao.ExerciseMapper;
import com.paf.exercise.dao.ExerciseService;
import com.paf.exercise.model.Exercise;

@RestController
public class ExerciseController 
{
	@Autowired
	public JdbcTemplate jdbcTemplate;
	@Autowired
	public ExerciseService exerciseservice;

	@GetMapping("/exercise")
	public List<Exercise> exercise(@RequestParam String operation,
								   @RequestParam(required = false) Integer tournament_id,
								   @RequestParam(required = false) Integer reward_amount,
								   @RequestParam(required = false) Integer player_id,
								   @RequestParam(required = false) String player_name) 
	{
		List<Exercise> list = new ArrayList<>();
		
		if (operation.equals("getTournaments")) {
			//exerciseservice.gettournments();
			String sql="select * from exercise where player_id is null";
			list = jdbcTemplate.query(sql, new ExerciseMapper());
		} 
		else if (operation.contains("getTournament")) {
			exerciseservice.getTournment(tournament_id);
		} 
		else if (operation.equals("addTournament")) {

			exerciseservice.addTournment(reward_amount);
			
		} else if (operation.equals("updateTournament")) {
			exerciseservice.updateTournment(reward_amount, tournament_id);
		} 
		else if (operation.equals("removeTournament")) {
			exerciseservice.removeTournment(tournament_id);
		} 
		else if (operation.equals("addPlayerIntoTournament")) {
			exerciseservice.addPlayer(tournament_id, player_name);
		} 
		else if (operation.equals("removePlayerFromTournament")) {
			exerciseservice.removePlayer(tournament_id, player_id);
		} 
		else if (operation.equals("getPlayersInTournament")) {
			//exerciseservice.getallPlayers(tournament_id);
			String sql="select * from exercise where tournament_id=" + tournament_id + " and player_id is not null";
			list = jdbcTemplate.query(sql, new ExerciseMapper());
			System.out.println("controller"+list);
		}
		return list;
	}
}
